﻿using System;
using System.IO;
using System.Media;

class Program
{
    static void Main()
    {
        // Play the startup audio greeting
        PlayStartupAudio();

        // Display ASCII banner
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\r\n              ___.                                                           \r\n  ____ ___.__.\\_ |__   ___________  ______ ____   ____  __ _________   ____  \r\n_/ ___<   |  | | __ \\_/ __ \\_  __ \\/  ___// __ \\_/ ___\\|  |  \\_  __ \\_/ __ \\ \r\n\\  \\___\\___  | | \\_\\ \\  ___/|  | \\/\\___ \\\\  ___/\\  \\___|  |  /|  | \\/\\  ___/ \r\n \\___  > ____| |___  /\\___  >__|  /____  >\\___  >\\___  >____/ |__|    \\___  >\r\n     \\/\\/          \\/     \\/           \\/     \\/     \\/                   \\/ \r\n");
        Console.ResetColor();

        // Ask user for their name
        Console.Write("Please enter your name: ");
        string name = Console.ReadLine();
        Console.WriteLine($"\nWelcome, {name}! Let’s talk about staying safe online.");

        // Main chatbot loop
        while (true)
        {
            Console.Write("\nAsk me a question (type 'exit' to quit): ");
            string input = Console.ReadLine().ToLower();

            if (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("Please enter a valid question.");
            }
            else if (input.Contains("how are you"))
            {
                Console.WriteLine("I'm great, ready to help you stay safe online!");
            }
            else if (input.Contains("purpose"))
            {
                Console.WriteLine("I'm here to raise awareness about cybersecurity.");
            }
            else if (input.Contains("password"))
            {
                Console.WriteLine("Use strong, unique passwords and enable two-factor authentication.");
            }
            else if (input.Contains("phishing"))
            {
                Console.WriteLine("Be cautious of emails asking for personal info. Don’t click suspicious links.");
            }
            else if (input.Contains("safe browsing"))
            {
                Console.WriteLine("Always check URLs and use HTTPS websites when browsing.");
            }
            else if (input == "exit")
            {
                Console.WriteLine("Goodbye! Stay safe online!");
                break;
            }
            else
            {
                Console.WriteLine("I didn’t quite understand that. Could you rephrase?");
            }
        }
        //exit visual
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("============== CYBERSECURITY CHATBOT ==============");
        Console.ResetColor();
    }

    // Function to play audio at startup
    static void PlayStartupAudio()
    {
        try
        {
            string path = @"C:\Users\thatb\source\repos\CyberSecurityChatBot\CyberSecurityChatBot\greeting.wav"; // Test with a system sound
            SoundPlayer player = new SoundPlayer(path);
            player.Load();
            player.PlaySync();
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Audio playback failed: " + ex.Message);
            Console.ResetColor();
        }
    }

}
