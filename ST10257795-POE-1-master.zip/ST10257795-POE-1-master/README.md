CyberSecurity Awareness ChatBot 

Description
A fun and interactive console chatbot that helps users learn about cybersecurity.

Features
- Voice greeting
- ASCII art welcome screen
- Personalised chat
- Cybersecurity tips
- Input validation
- CI with GitHub Actions

How to Run
1. Open in Visual Studio
2. Press F5 to run
